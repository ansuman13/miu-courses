
public class CalculateTwoInteger  {
	
	public CalculateTwoInteger () {
				
	}

	
	public int sum(int x, int y)
	{
		return (x +y);
	}
	

	public int product(int x, int y)
	{
		return (x * y);
	}


}
